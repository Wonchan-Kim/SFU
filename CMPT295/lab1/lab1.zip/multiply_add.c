#include <stdint.h>

int64_t multiply_add(int64_t a, int64_t b, int64_t c) {
    return a + b * c;
}

